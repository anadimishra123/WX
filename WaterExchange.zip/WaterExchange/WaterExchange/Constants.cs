﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaterExchange
{
    public class Constants
    {
        
        public const string organizationName = "WE_OrganizationName";
        public const string organizationType = "WE_OrganizationType";
        public const string orgWebSite = "WE_OrgWebSite";
        public const string orgURL = "WE_OrgURL";
        public const string emailDomain = "WE_EmailDomain";
        public const string firstName = "WE_UserFirstName";
        public const string lastName = "WE_UserLastName";
        public const string userTitle = "WE_UserTitle";
        public const string email = "WE_UserEmail";
        public const string password = "WE_Password";
        public const string linkedIn = "WE_UserLinkedin";
        public const string weeklyTrends = "WE_UserWeeklyTrends";
        public const string paymentID = "WE_OrgPaymentRefID";
        public const string paymentStatus = "WE_OrgPaymentStatus";
        public const string emailSent = "WE_UserEmailSent";
        public const string userOrg = "WE_UserOrg";
        public const string orgStatus = "WE_OrgStatus";
        public const string userStatus = "WE_UserStatus";
        public const string userCreated = "WE_UserCreated";
        public const string siteCreated = "WE_OrgSiteCreated";
        public const string userAdded = "WE_UserAdded";
        public const string orgAdmin = "WE_UserOrgAdmin";
        public const string joineeEmails = "JoineeEmails";
        public const string cSV = "CSV";
        public const string status = "Status";
        public const string organizationList= "Organizations";
        public const string joineesList = "Users";
        public const string StripeprivateKey = "sk_test_1U4SwcdP820VxPDptEBZjcuW";
        public const string ConfigMasterList = "Configuration Master";        
        public const string MailConfigList = "Mail Config";
        public const string Approved = "Setup and Active";
        public const string ApprovedButNotSetup = "Approved, Not fully setup";
        public const string Pending = "Waiting for Approval";
        public const string Rejected = "Denied / Inactive";
        public const string Inactive = "Inactive";
        public const string joineeEmail = "JoineeEmail";
        public const string JoineeCreationApproval = "Joinee Creation Approval";
        public const string JoineeApproval = "Joinee Approval";
        public const string JoineeRejection= "Joinee Rejection";
        public const string JoineeApprovedStatus = "Approved";
        public const string JoineeDeniedStatus = "Denied";
        public const string OrganizationRejection = "Organization Rejection";
        public const string OrganizationApprovalEmail = "Organization Creation Approval";
        public const string ApprovalRejectionEmailSent = "WE_UserAppRejEmailSent";
        public const string Declined = "Declined";
        public const string PreApprovedJoineesList = "PreApprovedJoinees";
        public const string OrganizationApproval= "Organization Approval";
        public const string ResetPassword = "Reset Password";


        //public const string 
    }

   

    public class Card
    {
        public string Country { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string ZipCode { get; set; }
        public string CardCvc { get; set; }
        public string CardExpirationMonth { get; set; }
        public string CardExpirationYear { get; set; }
        public string CardName { get; set; }
        public string CardNumber { get; set; }

    }
}
