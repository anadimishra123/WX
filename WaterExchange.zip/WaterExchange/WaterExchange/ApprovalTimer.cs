﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System.Configuration;
using System.Web.Configuration;
using System.Web.Security;

namespace WaterExchange
{
    public class ApprovalTimer : SPJobDefinition
    {
        const string JobName = "Approval TimerJob";
        string membserhip = "WaterExchangeMembership";
        string siteURL = ConfigurationManager.AppSettings["SiteURL"];
        public ApprovalTimer() : base() { }

        public ApprovalTimer(string jobName, SPService service) :
            base(jobName, service, null, SPJobLockType.None)
        {
            this.Title = JobName;
        }

        public ApprovalTimer(string jobName, SPWebApplication webapp) :
            base(jobName, webapp, null, SPJobLockType.ContentDatabase)
        {
            this.Title = JobName;
        }

        /// <summary>
        /// This is default method of Timer Job and will perform all the Post Approval/Rejection operations for Organization and Joinees
        /// </summary>
        /// <param name="targetInstanceId"></param>
        public override void Execute(Guid targetInstanceId)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate
            {

                try
                {
                    ApproveOrganization();
                    ApproveJoinee();
                    RejectOrganization();
                    RejectJoinee();
                }
                catch (SPException ex)
                {
                    Utility.LogError(JobName, ex);                    
                }
                catch (Exception ex)
                {
                    Utility.LogError(JobName, ex);
                }
            });
        }



        /// <summary>
        /// This function will create Org Site, create FBA User for Org Admin and Send Email
        /// </summary>
        private void ApproveOrganization()
        {
            bool isSiteCreated = false, isUserCreated = false, isEmailSent = false;
            string URL = string.Empty, message = string.Empty;
            string camlQuery = @"<Where>
                                      <And>
                                         <Eq>
                                            <FieldRef Name='WE_OrgStatus' />
                                            <Value Type='Choice'>" + Constants.Approved + @"</Value>
                                         </Eq>
                                         <Or>
                                            <Eq>
                                               <FieldRef Name='WE_OrgSiteCreated' />
                                               <Value Type='Boolean'>0</Value>
                                            </Eq>
                                            <Or>
                                               <Eq>
                                                  <FieldRef Name='WE_UserCreated' />
                                                  <Value Type='Boolean'>0</Value>
                                               </Eq>
                                               <Eq>
                                                  <FieldRef Name='WE_UserAppRejEmailSent' />
                                                  <Value Type='Boolean'>0</Value>
                                               </Eq>
                                            </Or>
                                         </Or>
                                      </And>
                                   </Where>";
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    using (SPSite site = new SPSite(siteURL))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList listOrganization = web.Lists.TryGetList(Constants.organizationList);

                            if (listOrganization != null)
                            {
                                SPQuery query = new SPQuery();
                                query.Query = camlQuery;
                                SPListItemCollection coll = listOrganization.GetItems(query);
                                if (coll != null && coll.Count > 0)
                                {
                                    for (int i = (coll.Count - 1); i >= 0; i--)
                                    {
                                        isSiteCreated = false; isUserCreated = false; isEmailSent = false; URL = string.Empty;
                                        SPListItem item = coll[i];
                                        isSiteCreated = Convert.ToBoolean(item[Constants.siteCreated]);
                                        isUserCreated = Convert.ToBoolean(item[Constants.userCreated]);
                                        isEmailSent = Convert.ToBoolean(item[Constants.ApprovalRejectionEmailSent]);

                                        FBAUser user = new FBAUser();
                                        user.Name = Convert.ToString(item[Constants.firstName]) + " " + Convert.ToString(item[Constants.lastName]);
                                        user.Email = Convert.ToString(item[Constants.email]);
                                        user.Password = Utility.Decrypt(Convert.ToString(item[Constants.password]));
                                        user.OrganizationName = Convert.ToString(item[Constants.organizationName]);
                                        web.AllowUnsafeUpdates = true;
                                        if (!isSiteCreated && isUserCreated)
                                        {
                                            try
                                            {
                                                SPWeb webOrg = web.Webs.Add(user.OrganizationName.Replace(" ", ""), user.OrganizationName, string.Empty, Convert.ToUInt32(1033), SPWebTemplate.WebTemplateSTS, true, false);
                                                URL = webOrg.Url;

                                                string userName = string.Concat("i:0#.f|", membserhip, "|", user.Email);
                                                SPRoleAssignment roleAssignment = new SPRoleAssignment(userName, user.Email, user.Name, string.Empty);
                                                SPRoleDefinition roleDefinition = webOrg.RoleDefinitions.GetByType(SPRoleType.Administrator);
                                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                                webOrg.AllowUnsafeUpdates = true;
                                                webOrg.RoleAssignments.Add(roleAssignment);
                                                webOrg.Update();
                                                webOrg.AllowUnsafeUpdates = false;
                                                isSiteCreated = true;
                                                item[Constants.siteCreated] = "1";
                                                item[Constants.orgURL] = URL;
                                            }
                                            catch(Exception ex)
                                            {
                                                isSiteCreated = false;
                                                Utility.LogError("WaterXchange: Approve Organization - " + JobName, ex);
                                            }
                                        }

                                        if (isSiteCreated && isUserCreated && !isEmailSent)
                                        {
                                            try
                                            {
                                                if (string.IsNullOrEmpty(URL))
                                                    URL = Convert.ToString(item[Constants.orgURL]);

                                                string subject = string.Empty, body = string.Empty;
                                                //Getting Email Subject and Body
                                                Utility.GetEmailSubjectAndBody(web, Constants.OrganizationApproval, out subject, out body);
                                                if (!string.IsNullOrEmpty(subject) && !string.IsNullOrEmpty(body))
                                                {
                                                    body = string.Format(body, URL);
                                                    string fromEmail = "admin@WaterXchange.org";
                                                    isEmailSent = Utility.SendEmail(user.Email, fromEmail, subject, body, siteURL);
                                                    if (isEmailSent)
                                                    {
                                                        item[Constants.ApprovalRejectionEmailSent] = "1";
                                                        try
                                                        {
                                                            //Adding Org Admin to Joinees list                                          
                                                            SPList listJoinees = web.Lists.TryGetList(Constants.joineesList);
                                                            SPListItem itemJoinee = listJoinees.AddItem();
                                                            itemJoinee[Constants.userOrg] = item.ID;
                                                            itemJoinee[Constants.email] = user.Email;
                                                            itemJoinee[Constants.firstName] = Convert.ToString(item[Constants.firstName]);
                                                            itemJoinee[Constants.lastName] = Convert.ToString(item[Constants.lastName]);
                                                            itemJoinee[Constants.userTitle] = Convert.ToString(item[Constants.userTitle]);
                                                            itemJoinee[Constants.password] = Utility.Encrypt(user.Password);
                                                            itemJoinee[Constants.weeklyTrends] = Convert.ToString(item[Constants.weeklyTrends]);
                                                            itemJoinee[Constants.userCreated] = "1";
                                                            itemJoinee[Constants.emailSent] = "1";
                                                            itemJoinee[Constants.ApprovalRejectionEmailSent] = "1";
                                                            itemJoinee[Constants.userAdded] = "1";
                                                            itemJoinee[Constants.orgAdmin] = "1";
                                                            itemJoinee[Constants.status] = Constants.JoineeApprovedStatus;
                                                            web.AllowUnsafeUpdates = true;
                                                            itemJoinee.Update();
                                                        }
                                                        catch (Exception ex)
                                                        {
                                                            Utility.LogError("WaterXchange: Approve Organization - " + JobName, ex);
                                                        }
                                                    }
                                                }
                                            }
                                            catch(Exception ex)
                                            {
                                                isEmailSent = false;
                                                Utility.LogError("WaterXchange: Approve Organization - " + JobName, ex);
                                            }
                                        }
                                        if (isSiteCreated || isEmailSent)
                                        {
                                            item.Update();
                                        }
                                        web.AllowUnsafeUpdates = false;
                                    }
                                }
                            }
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                Utility.LogError("WaterXchange: Approve Organization - " + JobName, ex);
            }
        }


        /// <summary>
        /// This function will create FBA Joinee User for Org and Send Email
        /// </summary>
        private void ApproveJoinee()
        {
            bool isUserCreated = false, isEmailSent = false, isUserAdded = false;
            string URL = string.Empty, message = string.Empty;
            string camlQuery = @"<Where>
                                      <And>
                                         <Eq>
                                            <FieldRef Name='WE_UserStatus' />
                                            <Value Type='Choice'>" + Constants.JoineeApprovedStatus + @"</Value>
                                         </Eq>
                                         <Or>
                                            <Eq>
                                               <FieldRef Name='WE_UserCreated' />
                                               <Value Type='Boolean'>0</Value>
                                            </Eq>
                                            <Or>
                                               <Eq>
                                                  <FieldRef Name='WE_UserAdded' />
                                                  <Value Type='Boolean'>0</Value>
                                               </Eq>
                                               <Eq>
                                                  <FieldRef Name='WE_UserAppRejEmailSent' />
                                                  <Value Type='Boolean'>0</Value>
                                               </Eq>
                                            </Or>
                                         </Or>
                                      </And>
                                   </Where>";
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    using (SPSite site = new SPSite(siteURL))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList listJoinee = web.Lists.TryGetList(Constants.joineesList);

                            if (listJoinee != null)
                            {
                                SPQuery query = new SPQuery();
                                query.Query = camlQuery;
                                SPListItemCollection coll = listJoinee.GetItems(query);
                                if (coll != null && coll.Count > 0)
                                {
                                    for (int i = (coll.Count - 1); i >= 0; i--)
                                    {
                                        SPListItem item = coll[i];

                                        //var Organization = (SPFieldLookupValue)item[Constants.userOrg];
                                        var Organization = new SPFieldLookupValue(item[Constants.userOrg] as string ?? string.Empty);
                                        SPList listOrganization = web.Lists.TryGetList(Constants.organizationList);
                                        SPListItem itemOrg = listOrganization.GetItemById(Organization.LookupId);
                                        isUserCreated = false; isEmailSent = false; isUserAdded = false;
                                        isUserCreated = Convert.ToBoolean(item[Constants.userCreated]);
                                        isEmailSent = Convert.ToBoolean(item[Constants.ApprovalRejectionEmailSent]);
                                        isUserAdded = Convert.ToBoolean(item[Constants.userAdded]);

                                        FBAUser user = new FBAUser();
                                        user.Name = Convert.ToString(item[Constants.firstName]) + " " + Convert.ToString(item[Constants.lastName]);
                                        user.Email = Convert.ToString(item[Constants.email]);
                                        user.Password = Utility.Decrypt(Convert.ToString(item[Constants.password]));
                                        user.SiteURL = Convert.ToString(itemOrg[Constants.orgURL]);

                                        if (!isUserAdded && isUserCreated)
                                        {
                                            try
                                            {
                                                using (SPSite siteOrg = new SPSite(user.SiteURL))
                                                {
                                                    SPWeb webOrg = siteOrg.OpenWeb();
                                                    string userName = string.Concat("i:0#.f|", membserhip, "|", user.Email);
                                                    SPRoleAssignment roleAssignment = new SPRoleAssignment(userName, user.Email, user.Name, string.Empty);
                                                    SPRoleDefinition roleDefinition = webOrg.RoleDefinitions.GetByType(SPRoleType.Reader);
                                                    roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                                    webOrg.AllowUnsafeUpdates = true;
                                                    webOrg.RoleAssignments.Add(roleAssignment);
                                                    webOrg.Update();
                                                    isUserAdded = true;
                                                    webOrg.AllowUnsafeUpdates = false;

                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                isUserAdded = false;
                                                Utility.LogError("WaterXchange: Approve Joinee- " + JobName, ex);
                                            }
                                        }

                                        if (isUserAdded && !isEmailSent)
                                        {
                                            try
                                            {
                                                isEmailSent = false;
                                                string subject = string.Empty, body = string.Empty;

                                                //Getting Email Subject and Body
                                                Utility.GetEmailSubjectAndBody(web, Constants.JoineeApproval, out subject, out body);
                                                if (!string.IsNullOrEmpty(subject) && !string.IsNullOrEmpty(body))
                                                {
                                                    body = string.Format(body, user.SiteURL);
                                                    string fromEmail = "admin@WaterXchange.org";
                                                    isEmailSent = Utility.SendEmail(user.Email, fromEmail, subject, body, siteURL);
                                                }
                                            }
                                            catch(Exception ex)
                                            {
                                                isEmailSent = false;
                                                Utility.LogError("WaterXchange: Approve Joinee- " + JobName, ex);
                                            }
                                        }
                                        if (isUserAdded)
                                        {
                                            item[Constants.userAdded] = "1";
                                        }
                                        if (isEmailSent)
                                        {
                                            item[Constants.ApprovalRejectionEmailSent] = "1";
                                        }
                                        if (isUserAdded || isEmailSent)
                                        {
                                            web.AllowUnsafeUpdates = true;
                                            item.Update();
                                            web.AllowUnsafeUpdates = false;
                                        }
                                    }
                                }
                            }
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                Utility.LogError("WaterXchange: Approve Joinee- " + JobName, ex);
            }
        }


        /// <summary>
        /// This function will send the Rejection email to Org Admins and update the email status
        /// </summary>
        private void RejectOrganization()
        {
            bool isEmailSent = false;
            string URL = string.Empty, message = string.Empty;
            string camlQuery = @"<Where>
                                      <And>
                                         <Eq>
                                            <FieldRef Name='WE_OrgStatus' />
                                            <Value Type='Choice'>" + Constants.Rejected + @"</Value>
                                         </Eq>
                                         <Eq>
                                            <FieldRef Name='WE_UserAppRejEmailSent' />
                                            <Value Type='Boolean'>0</Value>
                                         </Eq>
                                      </And>
                                   </Where>";
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    using (SPSite site = new SPSite(siteURL))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList listOrganization = web.Lists.TryGetList(Constants.organizationList);
                            if (listOrganization != null)
                            {
                                SPQuery query = new SPQuery();
                                query.Query = camlQuery;
                                SPListItemCollection coll = listOrganization.GetItems(query);
                                if (coll != null && coll.Count > 0)
                                {
                                    for (int i = (coll.Count - 1); i >= 0; i--)
                                    {
                                        isEmailSent = false;
                                        SPListItem item = coll[i];
                                        isEmailSent = Convert.ToBoolean(item[Constants.ApprovalRejectionEmailSent]);
                                        FBAUser user = new FBAUser();
                                        user.Email = Convert.ToString(item[Constants.email]);
                                        if (!isEmailSent)
                                        {
                                            try
                                            {
                                                string subject = string.Empty, body = string.Empty;
                                                //Getting Email Subject and Body
                                                Utility.GetEmailSubjectAndBody(web, Constants.OrganizationRejection, out subject, out body);
                                                if (!string.IsNullOrEmpty(subject) && !string.IsNullOrEmpty(body))
                                                {
                                                    string fromEmail = "admin@WaterXchange.org";
                                                    isEmailSent = Utility.SendEmail(user.Email, fromEmail, subject, body, siteURL);
                                                }
                                            }
                                            catch(Exception ex)
                                            {
                                                isEmailSent = false;
                                                Utility.LogError("WaterXchange: Reject Organization - " + JobName, ex);
                                            }
                                        }
                                        if (isEmailSent)
                                        {
                                            item[Constants.ApprovalRejectionEmailSent] = "1";
                                            web.AllowUnsafeUpdates = true;
                                            item.Update();
                                            web.AllowUnsafeUpdates = false;
                                        }
                                    }
                                }
                            }
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                Utility.LogError("WaterXchange: Reject Organization - " + JobName, ex);
            }
        }
        

        /// <summary>
        /// This function will send the Rejection email to Org Joinees and update the email status
        /// </summary>
        private void RejectJoinee()
        {
            bool isEmailSent = false;
            string URL = string.Empty, message = string.Empty;
            string camlQuery = @"<Where>
                                      <And>
                                         <Eq>
                                            <FieldRef Name='WE_UserStatus' />
                                            <Value Type='Choice'>" + Constants.JoineeDeniedStatus + @"</Value>
                                         </Eq>
                                         <Eq>
                                            <FieldRef Name='WE_UserAppRejEmailSent' />
                                            <Value Type='Boolean'>0</Value>
                                         </Eq>
                                      </And>
                                   </Where>";
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    using (SPSite site = new SPSite(siteURL))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList listJoinee = web.Lists.TryGetList(Constants.joineesList);

                            if (listJoinee != null)
                            {
                                SPQuery query = new SPQuery();
                                query.Query = camlQuery;
                                SPListItemCollection coll = listJoinee.GetItems(query);
                                if (coll != null && coll.Count > 0)
                                {
                                    for (int i = (coll.Count - 1); i >= 0; i--)
                                    {
                                        SPListItem item = coll[i];
                                        //var Organization = (SPFieldLookupValue)item[Constants.userOrg];
                                        var Organization = new SPFieldLookupValue(item[Constants.userOrg] as string ?? string.Empty);
                                        SPList listOrganization = web.Lists.TryGetList(Constants.organizationList);
                                        SPListItem itemOrg = listOrganization.GetItemById(Organization.LookupId);

                                        string adminFirstName = Convert.ToString(itemOrg[Constants.firstName]);
                                        string adminLastName = Convert.ToString(itemOrg[Constants.lastName]);
                                        string adminEmail = Convert.ToString(itemOrg[Constants.email]);


                                        isEmailSent = Convert.ToBoolean(item[Constants.ApprovalRejectionEmailSent]);

                                        FBAUser user = new FBAUser();
                                        user.Email = Convert.ToString(item[Constants.email]);

                                        if (!isEmailSent)
                                        {
                                            try
                                            {
                                                isEmailSent = false;
                                                string subject = string.Empty, body = string.Empty;

                                                //Getting Email Subject and Body
                                                Utility.GetEmailSubjectAndBody(web, Constants.JoineeRejection, out subject, out body);
                                                if (!string.IsNullOrEmpty(subject) && !string.IsNullOrEmpty(body))
                                                {
                                                    body = string.Format(body, adminFirstName, adminLastName, adminEmail);
                                                    string fromEmail = "admin@WaterXchange.org";
                                                    isEmailSent = Utility.SendEmail(user.Email, fromEmail, subject, body, siteURL);
                                                }
                                            }
                                            catch(Exception ex)
                                            {
                                                isEmailSent = false;
                                                Utility.LogError("WaterXchange: Reject Joinee- " + JobName, ex);
                                            }
                                        }
                                        if (isEmailSent)
                                        {
                                            item[Constants.ApprovalRejectionEmailSent] = "1";
                                            web.AllowUnsafeUpdates = true;
                                            item.Update();
                                            web.AllowUnsafeUpdates = false;
                                        }
                                    }
                                }
                            }
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                Utility.LogError("WaterXchange: Reject Joinee- " + JobName, ex);
            }
        }
    }
}
