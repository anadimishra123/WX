﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.IdentityModel.Pages;
using Microsoft.SharePoint.Utilities;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using Microsoft.SharePoint.Administration;
using System.Web.Configuration;
using Stripe;
using System.Globalization;
using System.Text;
using System.Collections.Specialized;
using System.Net.Mail;

namespace WaterExchange.Layouts.WaterExchange
{
    public partial class RegisterOrg : FormsSignInPage
    {
        #region Variables

        string organization = string.Empty;
        string type = string.Empty;
        string website = string.Empty;
        string domain = string.Empty;
        string firstName = string.Empty;
        string lastName = string.Empty;
        string title = string.Empty;
        string email = string.Empty;
        string isLinkedin = string.Empty;
        string isWeeklyTrends = string.Empty;
        string cardName = string.Empty;
        string creditCard = string.Empty;
        string expMonth = string.Empty;
        string expYear = string.Empty;
        string CSV = string.Empty;
        string password = string.Empty;


        #endregion



        protected override void OnInit(EventArgs eventArgs)
        {
            base.OnInit(eventArgs);
        }
        protected override void OnLoad(EventArgs e)
        {
            try
            {
                txtPassword.Attributes["value"] = txtPassword.Text;
                if (!IsPostBack)
                {
                    txtCreditCard.Value = "4242-4242-4242-4242";
                    txtCSV.Value = "123";
                    txtExpYear.Value = "12/20";
                    txtNameCard.Value = "sharath";
                }

                base.OnLoad(e);
            }
            catch { }
        }

        private void ShowNextStep(HtmlGenericControl divName)
        {
            divStep1.Style.Add("display", "none");
            divStep2.Style.Add("display", "none");
            divStep3.Style.Add("display", "none");
            divSuccess.Style.Add("display", "none");
            divName.Style.Add("display", "block");

        }

        protected void btnContinueStep2_Click(object sender, EventArgs e)
        {
            ShowNextStep(divStep3);
        }


        protected void btnContinueStep1_Click(object sender, EventArgs e)
        {
            string camlQuery = @"<Where>
                                    <Or>
                                        <Eq>
                                            <FieldRef Name='WE_EmailDomain' />
                                            <Value Type='Text'>{0}</Value>
                                        </Eq>
                                        <Eq>
                                            <FieldRef Name='WE_OrganizationName' />
                                            <Value Type='Text'>{1}</Value>
                                        </Eq>
                                    </Or>
                                </Where>";
            organization = txtOrganization.Value.Trim();
            domain = txtDomain.Value.Trim();
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    string siteURL = SPContext.Current.Site.Url;
                    using (SPSite site = new SPSite(siteURL))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList listOrganization = web.Lists.TryGetList(Constants.organizationList);

                            if (listOrganization != null)
                            {
                                SPQuery query = new SPQuery();
                                query.Query = string.Format(camlQuery, domain, organization);
                                SPListItemCollection coll = listOrganization.GetItems(query);
                                if (coll.Count == 0)
                                {
                                    ShowNextStep(divStep2);
                                }
                                else
                                {
                                    lblOrgError.Text = "<br/><br/>Organization or Domain entered already exists";
                                }

                            }
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                lblMessage.Text = "<br/><br/>" + ex.Message;
                Utility.LogError("WaterXchange - Register Organization ", ex);
            }
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                string ChargeId = ProcessPayment();
                //string ChargeId = "";
                if (!string.IsNullOrEmpty(ChargeId))
                {
                    organization = txtOrganization.Value.Trim();
                    type = rbtnType.SelectedValue;
                    website = txtWebsite.Value.Trim();
                    domain = txtDomain.Value.Trim();
                    firstName = txtFirstName.Value.Trim();
                    lastName = txtLastName.Value.Trim();
                    title = txtTitle.Value.Trim();
                    email = txtEmail.Value.Trim();
                    //isLinkedin = rbtnLinkedin.SelectedValue;
                    isWeeklyTrends = rbtnNewsletter.SelectedValue;
                    cardName = txtNameCard.Value.Trim();
                    creditCard = txtCreditCard.Value.Trim();
                    expYear = txtExpYear.Value.Trim();
                    //expMonth = txtExpMonth.Value.Trim();
                    CSV = txtCSV.Value.Trim();
                    password = txtPassword.Text.Trim();
                    string camlQuery = @"<Where>
                                            <Or>
                                                <Eq>
                                                   <FieldRef Name='WE_OrganizationName' />
                                                   <Value Type='Text'>{0}</Value>
                                                </Eq>
                                                 <Or>
                                                    <Eq>
                                                        <FieldRef Name='WE_EmailDomain' />
                                                        <Value Type='Text'>{1}</Value>
                                                    </Eq>
                                                    <Eq>
                                                        <FieldRef Name='WE_UserEmail' />
                                                        <Value Type='Text'>{2}</Value>
                                                    </Eq>
                                                </Or>
                                            </Or>
                                        </Where>";
                    SPSecurity.RunWithElevatedPrivileges(delegate
                    {
                        string siteURL = SPContext.Current.Site.Url;
                        using (SPSite site = new SPSite(siteURL))
                        {
                            using (SPWeb web = site.OpenWeb())
                            {
                                SPList listOrganization = web.Lists.TryGetList(Constants.organizationList);

                                if (listOrganization != null)
                                {
                                    SPQuery query = new SPQuery();
                                    query.Query = string.Format(camlQuery, organization, domain, email);
                                    SPListItemCollection coll = listOrganization.GetItems(query);
                                    if (coll != null && coll.Count == 0)
                                    {
                                        #region Create Organization

                                        SPListItem item = listOrganization.AddItem();
                                        item[Constants.organizationName] = organization;
                                        item[Constants.organizationType] = type;
                                        item[Constants.orgWebSite] = website;
                                        item[Constants.emailDomain] = domain;
                                        item[Constants.firstName] = firstName;
                                        item[Constants.lastName] = lastName;
                                        item[Constants.userTitle] = title;
                                        item[Constants.email] = email;
                                        item[Constants.password] = Utility.Encrypt(password);
                                        item[Constants.weeklyTrends] = isWeeklyTrends;
                                        item[Constants.paymentID] = ChargeId;
                                        item[Constants.orgStatus] = Constants.Pending;
                                        item[Constants.userCreated] = "0";
                                        item[Constants.siteCreated] = "0";
                                        item[Constants.emailSent] = "0";
                                        item[Constants.ApprovalRejectionEmailSent] = "0";
                                        item[Constants.paymentStatus] = Constants.JoineeApprovedStatus;
                                        web.AllowUnsafeUpdates = true;
                                        item.Update();
                                        web.AllowUnsafeUpdates = false;

                                        #endregion


                                        #region Send Email for Approval

                                        string approvalGroup = GetApprovalGroup(web);
                                        if (!string.IsNullOrEmpty(approvalGroup))
                                        {
                                            StringBuilder approverEmails = new StringBuilder();
                                            approverEmails.Append(approvalGroup);

                                            string subject = string.Empty, body = string.Empty;
                                            //Getting Email Subject and Body
                                            Utility.GetEmailSubjectAndBody(web, Constants.OrganizationApprovalEmail, out subject, out body);
                                            if (!string.IsNullOrEmpty(subject) && !string.IsNullOrEmpty(body))
                                            {
                                                string approvalPage = string.Concat(web.Site.Url, WebConfigurationManager.AppSettings["OrgApprovalPage"], "?ID=" + item.ID + "&Status=" + Constants.JoineeApprovedStatus);
                                                string declinePage = string.Concat(web.Site.Url, WebConfigurationManager.AppSettings["OrgApprovalPage"], "?ID=" + item.ID + "&Status=" + Constants.Declined);
                                                body = string.Format(body, organization, type, website, domain, firstName, lastName, email, title, approvalPage, declinePage);
                                                string fromEmail = WebConfigurationManager.AppSettings["FromEmail"];
                                                bool isEmailSent = Utility.SendEmail(Convert.ToString(approverEmails), fromEmail, subject, body);
                                                if (isEmailSent)
                                                {
                                                    item[Constants.emailSent] = "1";

                                                    web.AllowUnsafeUpdates = true;
                                                    item.Update();
                                                    web.AllowUnsafeUpdates = false;
                                                    ShowNextStep(divSuccess);
                                                }
                                                else
                                                {
                                                    //lblEmailSent.Text = "Email is not sent to B&C administrator due to some technical reasons";
                                                    ShowNextStep(divSuccess);
                                                }
                                            }
                                        }

                                        #endregion
                                    }
                                    else
                                    {
                                        lblMessage.Text = "<br/><br/>Organization or Domain entered already exists";
                                    }
                                }
                            }
                        }
                    });
                }
                else
                {
                    lblMessage.Text = "<br/><br/>Credit Card supplied is not valid";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = "<br/><br/>" + ex.Message;
                Utility.LogError("WaterXchange - Register Organization ", ex);
            }
        }



        private string GetApprovalGroup(SPWeb web)
        {

            string camlQuery = @"<Where><Eq>
                                                <FieldRef Name='Key' />
                                                <Value Type='Text'>{0}</Value>
                                            </Eq>                                           
                                        </Where>";
            SPQuery query = new SPQuery();
            query.Query = string.Format(camlQuery, "Approver Group");
            query.ViewFields = "<FieldRef Name ='Value'/>";


            SPList listConfigMaster = web.Lists.TryGetList(Constants.ConfigMasterList);
            SPListItemCollection itemConfig = listConfigMaster.GetItems(query);
            string approverGroup = string.Empty;
            if (itemConfig != null && itemConfig.Count > 0)
            {
                approverGroup = Convert.ToString(itemConfig[0]["Value"]);
            }
            return approverGroup;
        }

        private string ProcessPayment()
        {
            StripeConfiguration.SetApiKey(Constants.StripeprivateKey);

            string strChargeId = string.Empty;
            string[] splitYearMonth = txtExpYear.Value.Split('/');
            string month = string.Empty, year = string.Empty;
            if (splitYearMonth.Length > 1)
            {
                month = splitYearMonth[0];
                year = splitYearMonth[1];
            }
            Card objCard = new Card
            {
                Country = "Brazil (BR)",
                AddressLine1 = "",
                AddressLine2 = "",
                City = "Test",
                ZipCode = "Test",
                CardCvc = txtCSV.Value,
                CardExpirationMonth = month,
                CardExpirationYear = year,
                CardName = txtNameCard.Value,
                CardNumber = txtCreditCard.Value
            };

            try
            {
                string strTokenId = GetTokenId(objCard);

                strChargeId = ChargeCustomer(strTokenId);

                lblPaymentID.Text = "Payment Successfull!! Reference ID: " + strChargeId;
                lblPaymentID.ForeColor = System.Drawing.Color.Blue;
            }
            catch (Exception ex)
            {
                lblMessage.Text = "<br/><br/>" + ex.Message;
                lblMessage.ForeColor = System.Drawing.Color.Red;
                strChargeId = string.Empty;
                Utility.LogError("WaterXchange - Process Payment", ex);
            }
            return strChargeId;
        }

        private string GetTokenId(Card objCard)
        {
            var stripetoken = new StripeTokenCreateOptions();

            var CreditCardOptions = new StripeCreditCardOptions
            {
                AddressCountry = objCard.Country,
                AddressLine1 = objCard.AddressLine1,
                AddressLine2 = objCard.AddressLine2,
                AddressCity = objCard.City,
                AddressZip = objCard.ZipCode,
                Cvc = objCard.CardCvc.ToString(CultureInfo.CurrentCulture),
                ExpirationMonth = objCard.CardExpirationMonth,
                ExpirationYear = objCard.CardExpirationYear,
                Name = objCard.CardName,
                Number = objCard.CardNumber
            };

            stripetoken.Card = CreditCardOptions;

            var tokenService = new StripeTokenService();
            var stripeToken = tokenService.Create(stripetoken);

            return stripeToken.Id;

        }

        private string ChargeCustomer(string tokenId)
        {

            var myCharge = new StripeChargeCreateOptions
            {
                Amount = 500,
                Currency = "usd",
                Description = "Charge for property sign and postage",
                SourceTokenOrExistingSourceId = tokenId
            };

            var chargeService = new StripeChargeService();
            var stripeCharge = chargeService.Create(myCharge);

            return stripeCharge.Id;

        }

    }


}
