﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.IdentityModel.Pages;
using Microsoft.SharePoint.Utilities;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using Microsoft.SharePoint.Administration;
using System.Web.Configuration;

namespace WaterExchange.Layouts.WaterExchange
{
    public partial class SignUp : FormsSignInPage
    {
        protected override void OnInit(EventArgs eventArgs)
        {
            base.OnInit(eventArgs);
        }
        protected override void OnLoad(EventArgs e)
        {
            try
            {
                base.OnLoad(e);
            }
            catch { }
        }

        protected void btnSignUp_Click(object sender, EventArgs e)
        {
            string message = "";
            try
            {

                string Name = txtUserName.Value.Trim();
                string email = txtEmail.Value.Trim();
                string password = txtPassword.Value.Trim();

                message += "1,";
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    message += "2,";
                    string membserhip = "WaterExchangeMembership";
                    string fbaGroupName = "CloudShare Portal 2016 Visitors";
                    message += "Membership is: " + WebConfigurationManager.AppSettings["MembershipName"];
                    message += "2.5,";
                    MembershipUser userMembership = Membership.CreateUser(email, password, email);

                    message += "3,";
                    if (userMembership != null)
                    {
                        string siteURL = SPContext.Current.Site.Url;
                        using (SPSite site = new SPSite(siteURL))
                        {
                            SPWeb web = site.OpenWeb();
                            string userName = string.Concat("i:0#.f|", membserhip, "|", email);
                            web.AllowUnsafeUpdates = true;
                            web.SiteUsers.Add(userName, userName, Name, "");
                            SPUser user = web.SiteUsers[userName];
                            if (user != null)
                            {
                                web.Groups[fbaGroupName].AddUser(user);
                                web.Update();
                                web.AllowUnsafeUpdates = false;
                                divMessage.InnerText = "User Created successfully";
                            }
                            else
                            {
                                divMessage.InnerText = "Temporary unable to create User";
                            }

                        }
                    }
                });
            }
            catch (Exception ex)
            {
                divMessage.InnerText = "Error occured: " + ex.Message;// + message;
            }
        }
    }
}
