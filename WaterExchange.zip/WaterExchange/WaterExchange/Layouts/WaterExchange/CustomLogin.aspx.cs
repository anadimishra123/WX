﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.IdentityModel.Pages;
using Microsoft.SharePoint.Utilities;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.IdentityModel;
//using Microsoft.IdentityModel.Claims;
using Microsoft.SharePoint.Administration.Claims;
using System.IdentityModel.Tokens;
using System.Web.Security;
using System.Web.UI.HtmlControls;

namespace WaterExchange.Layouts.WaterExchange
{
    public partial class CustomLogin : FormsSignInPage
    {
        string redirectURL = "/_layouts/15/Authenticate.aspx";
        string membserhip = "WaterExchangeMembership";
        protected override void OnInit(EventArgs eventArgs)
        {
            base.OnInit(eventArgs);
        }
        protected override void OnLoad(EventArgs e)
        {
            try
            {
                base.OnLoad(e);

            }
            catch { }
        }

        protected void btnLogin_OnClick(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            bool status = false;
            string url = string.Empty;
            try
            {
                string UserName = txtEmail.Value.Trim();
                string Password = txtPassword.Value.Trim();

                status = SPClaimsUtility.AuthenticateFormsUser(Context.Request.UrlReferrer, UserName, Password);

                if (!status)// if forms auth failed
                {
                    lblError.Text = "<br/><br/>Wrong Userid or Password";
                }
                else //if success
                {
                    if (Request.QueryString["Source"] != null)
                    {
                        url = Request.QueryString["Source"];
                        Response.Redirect(url);
                    }
                    else if (Context.Request.QueryString.Keys.Count > 1)
                    {
                        Response.Redirect(Context.Request.QueryString["Source"].ToString());
                    }
                    else
                        Response.Redirect(Context.Request.QueryString["ReturnUrl"].ToString());
                    // Response.Redirect(SPContext.Current.Web.Url); //Use site url
                }
            }
            catch (Exception ex)
            {
                if (status)
                {
                    if (Request.QueryString["Source"] != null)
                    {
                        url = Request.QueryString["Source"];
                        Response.Redirect(url);
                    }
                    else
                        Response.Redirect(redirectURL);
                }
                else
                    lblError.Text = "<br/><br/>" + ex.Message;

                Utility.LogError("WaterXchange - Custom Login Page", ex);
            }
        }

        private void ShowDiv(HtmlGenericControl div)
        {
            mreset.Attributes["class"] = "hidden";
            msent.Attributes["class"] = "hidden";
            mlogin.Attributes["class"] = "hidden";

            div.Attributes["class"] = "show";
        }



        protected void btnReset_ServerClick(object sender, EventArgs e)
        {
            ShowDiv(mreset);
            string UserEmail = txtResetEmail.Value.Trim();
            MembershipUser userFBA = null;
            string userName = string.Concat("i:0#.f|", membserhip, "|", UserEmail);
            try
            {
                string siteURL = SPContext.Current.Site.Url;
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    using (SPSite site = new SPSite(siteURL))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            MembershipUserCollection usercoll = Membership.GetAllUsers();

                            bool bIsUserFound = false;
                            foreach (MembershipUser fbauser in usercoll)
                            {
                                if (fbauser.UserName == UserEmail)
                                {
                                    userFBA = fbauser;
                                    bIsUserFound = true;
                                    break;
                                }
                            }
                            //userFBA = Membership.GetUser(userName);
                            if (bIsUserFound)
                            {
                                string newPassword = userFBA.ResetPassword();

                                string subject = string.Empty, body = string.Empty;
                                //Getting Email Subject and Body
                                Utility.GetEmailSubjectAndBody(web, Constants.ResetPassword, out subject, out body);
                                if (!string.IsNullOrEmpty(subject) && !string.IsNullOrEmpty(body))
                                {
                                    body = string.Format(body, newPassword);
                                    bool isEmailSent = Utility.SendEmail(UserEmail, string.Empty, subject, body);
                                    ShowDiv(msent);
                                }
                            }
                            else
                            {
                                lblResetError.Text = "<br/><br/>Email entered does not exist";
                            }
                        }
                    }
                });

            }
            catch (Exception ex)
            {

                lblResetError.Text = "<br/><br/>Error while resetting password";
            }
        }
    }
}