﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.Security;
using System.Web.Configuration;

namespace WaterExchange.Layouts.WaterExchange
{
    public partial class ApproveForm : LayoutsPageBase
    {
        string orgID = string.Empty;
        string status = string.Empty;

        private void ShowDiv(string message)
        {
            divSuccess.Style.Add("display", "block");
            lblMessage.Text = message;
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    orgID = Request.QueryString["ID"];
                    status = Request.QueryString["Status"];
                    if (!string.IsNullOrEmpty(orgID) && !string.IsNullOrEmpty(status))
                    {
                        string siteURL = SPContext.Current.Site.Url;
                        //SPGroupCollection groupColl = SPContext.Current.Web.CurrentUser.Groups;
                        string approverEmail = SPContext.Current.Web.CurrentUser.Email;
                        string approverLoginName = SPContext.Current.Web.CurrentUser.LoginName.ToLower();
                        SPSecurity.RunWithElevatedPrivileges(delegate
                        {
                            using (SPSite site = new SPSite(siteURL))
                            {
                                using (SPWeb web = site.OpenWeb())
                                {
                                    Utility utility = new Utility();
                                    string approvalGroup = utility.GetApprovalGroup(web).ToLower();
                                    if (approvalGroup.Equals(approverEmail,StringComparison.CurrentCultureIgnoreCase) || approverLoginName.Contains(approvalGroup))
                                    {
                                        SPList listOrganization = web.Lists.TryGetList(Constants.organizationList);

                                        if (listOrganization != null)
                                        {
                                            SPListItem item = listOrganization.GetItemById(int.Parse(orgID));
                                            if (item != null)
                                            {
                                                if (Convert.ToString(item[Constants.orgStatus]).Equals(Constants.Pending))
                                                {
                                                    //lblOrganizationName.Text = Convert.ToString(item["OrganizationName"]);
                                                    //lblAdminName.Text = Convert.ToString(item["FirstName"]) + " " + Convert.ToString(item["LastName"]);
                                                    string message = utility.ApproveOrganization(orgID, status);
                                                    ShowDiv(message);
                                                }
                                                else
                                                {
                                                    ShowDiv("Organization selected for Approval/Rejection is no more valid or Organization does not exist.");
                                                }
                                            }
                                        }
                                        else
                                        {
                                            ShowDiv("Organization does not exists");
                                        }
                                        //SPGroup group = groupColl.GetByName(approvalGroup);                                           
                                        
                                    }
                                    else
                                    {
                                        ShowDiv("You are not the authorized approver");
                                    }


                                }

                            }
                        });

                    }
                    else
                    {
                        ShowDiv("You are not the authorized approver");
                    }

                }
            }
            catch (Exception ex)
            {
                ShowDiv(ex.Message);
                Utility.LogError("WaterXchange - Approve Organization Form", ex);
            }
        }

        
    }
}
