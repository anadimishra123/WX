﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;

namespace WaterExchange.Layouts.WaterExchange
{
    public partial class MultiApproval : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string siteURL = SPContext.Current.Site.Url;
                SPGroupCollection groupColl = SPContext.Current.Web.CurrentUser.Groups;
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    using (SPSite site = new SPSite(siteURL))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            Utility utility = new Utility();
                            string approvalGroup = utility.GetApprovalGroup(web);
                            if (!string.IsNullOrEmpty(approvalGroup))
                            {
                                try
                                {
                                    SPGroup group = groupColl.GetByName(approvalGroup);
                                    if (group == null)
                                    {
                                        ShowErrorDiv("You are not the authorized approver");
                                    }
                                    else
                                    {
                                        BindOrganization();
                                    }
                                }
                                catch (Exception ex)
                                {
                                    ShowErrorDiv("You are not the authorized approver");
                                }

                            }
                            else
                            {
                                ShowErrorDiv("You are not the authorized approver");
                            }



                        }

                    }
                });


            }
        }

        /// <summary>
        /// This function will Show Message
        /// </summary>
        /// <param name="message"></param>
        private void ShowDiv(string message)
        {
            lblMessage.Text = message;
        }


        private void ShowErrorDiv(string message)
        {
            divStep1.Style.Add("display", "none");
            divSuccess.Style.Add("display", "block");
            lblErrorMessage.Text = message;
        }

        protected void grdOrganizations_RowCommand(object sender, System.Web.UI.WebControls.GridViewCommandEventArgs e)
        {
            string currentCommand = e.CommandName;

            try
            {
                if (currentCommand.Equals("UpdateRow"))
                {
                    int currentRowIndex = Int32.Parse(e.CommandArgument.ToString());
                    string orgID = Convert.ToString(grdOrganizations.DataKeys[currentRowIndex].Value);
                    DropDownList ddlAction = (DropDownList)grdOrganizations.Rows[currentRowIndex].FindControl("ddlAction");
                    UpdateAction(orgID, ddlAction.SelectedValue);
                }

            }
            catch (Exception ex)
            {
                ShowDiv(ex.Message);
            }

        }


        /// <summary>
        /// This function will Update the ation initiated by BC Admin
        /// </summary>
        /// <param name="orgID"></param>
        /// <param name="action"></param>
        private void UpdateAction(string orgID, string action)
        {
            string message = string.Empty;
            Utility utility = new Utility();
            if (action.Equals(Constants.Approved))
            {
                message = utility.ApproveOrganization(orgID);
            }
            else if (action.Equals(Constants.Rejected))
            {
                message = utility.RejectOrganization(orgID);
            }
            else if (action.Equals(Constants.Inactive))
            {
                message = utility.InactiveOrganization(orgID);
            }
            ShowDiv(message);
            BindOrganization();
        }


        private void BindOrganization()
        {
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    string siteURL = SPContext.Current.Site.Url;
                    using (SPSite site = new SPSite(siteURL))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList listOrganization = web.Lists.TryGetList(Constants.organizationList);

                            if (listOrganization != null)
                            {
                                SPListItemCollection coll = listOrganization.GetItems(new SPQuery());
                                if (coll != null && coll.Count > 0)
                                {
                                    grdOrganizations.DataSource = coll.GetDataTable();
                                    grdOrganizations.DataBind();
                                }

                            }

                        }

                    }

                });
            }
            catch (Exception ex)
            {
                ShowDiv(ex.Message);
            }
        }
    }
}
