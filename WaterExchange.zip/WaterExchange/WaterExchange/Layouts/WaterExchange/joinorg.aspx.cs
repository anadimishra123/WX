﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.IdentityModel.Pages;
using Microsoft.SharePoint.Utilities;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using Microsoft.SharePoint.Administration;
using System.Web.Configuration;

namespace WaterExchange.Layouts.WaterExchange
{
    public partial class JoinOrganization : FormsSignInPage
    {

        #region Variables

        string firstName = string.Empty;
        string lastName = string.Empty;
        string title = string.Empty;
        string email = string.Empty;

        string isWeeklyTrends = string.Empty;
        string password = string.Empty;
        #endregion

        protected override void OnInit(EventArgs eventArgs)
        {
            base.OnInit(eventArgs);
        }
        protected override void OnLoad(EventArgs e)
        {
            try
            {
                txtPassword.Attributes["value"] = txtPassword.Text;
                base.OnLoad(e);
            }
            catch { }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="divName"></param>
        private void ShowNextStep(HtmlGenericControl divName)
        {

            divSuccess.Style.Add("display", "none");
            divFailure.Style.Add("display", "none");
            divJoinOrg.Style.Add("display", "none");
            divDuplicateEmail.Style.Add("display", "none");
            divName.Style.Add("display", "block");

        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
            try
            {

                bool isPreApproved = false;
                string preApprovedJoinees = string.Empty;
                firstName = txtFirstName.Value.Trim();
                lastName = txtLastName.Value.Trim();
                title = txtTitle.Value.Trim();
                email = txtEmail.Value.Trim();
                isWeeklyTrends = rbtnNewsletter.SelectedValue;
                password = txtPassword.Text.Trim();

                string emailDomain = string.Empty;
                if (!string.IsNullOrEmpty(email))
                {
                    string[] splitter = email.Split('@');
                    if (splitter.Length > 1)
                        emailDomain = "@" + splitter[1];
                }

                string camlQuery = @"<Where>
                                       <And>
                                            <Eq>
                                                <FieldRef Name='WE_EmailDomain' />
                                                <Value Type='Text'>{0}</Value>
                                            </Eq>
                                            <Eq>
                                                <FieldRef Name='WE_OrgStatus' />
                                                <Value Type='Text'>{1}</Value>
                                            </Eq>
                                       </And>
                                    </Where>";
                string camlJoineeQuery = @"<Where>                                       
                                            <Eq>
                                                <FieldRef Name='WE_UserEmail' />
                                                <Value Type='Text'>{0}</Value>
                                            </Eq>                                       
                                        </Where>";
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    string siteURL = SPContext.Current.Site.Url;
                    using (SPSite site = new SPSite(siteURL))
                    {
                        SPWeb web = site.OpenWeb();
                        SPList listOrganization = web.Lists.TryGetList(Constants.organizationList);
                        SPList listJoinees = web.Lists.TryGetList(Constants.joineesList);

                        if (listOrganization != null && listJoinees != null)
                        {
                            SPQuery query = new SPQuery();
                            query.Query = string.Format(camlQuery, emailDomain, Constants.Approved);
                            SPListItemCollection coll = listOrganization.GetItems(query);

                            query = new SPQuery();
                            query.Query = string.Format(camlJoineeQuery, email);
                            SPListItemCollection collJoinee = listJoinees.GetItems(query);
                            if (collJoinee.Count > 0)
                            {
                                ShowNextStep(divDuplicateEmail);
                            }
                            else if (coll.Count > 0)
                            {
                                string subSiteURL = Convert.ToString(coll[0][Constants.orgURL]);
                                preApprovedJoinees = Utility.GetPreApprovedJoinees(Convert.ToString(coll[0].ID));
                                if (preApprovedJoinees.Length > 0 && preApprovedJoinees.ToLower().Contains(email.ToLower()))
                                {
                                    isPreApproved = true;
                                }
                                else
                                    isPreApproved = false;

                                SPListItem item = listJoinees.AddItem();
                                item[Constants.userOrg] = coll[0].ID;
                                item[Constants.email] = email;
                                item[Constants.firstName] = firstName;
                                item[Constants.lastName] = lastName;
                                item[Constants.userTitle] = title;
                                item[Constants.password] = Utility.Encrypt(password);
                                item[Constants.weeklyTrends] = isWeeklyTrends;
                                item[Constants.userCreated] = "0";
                                item[Constants.userAdded] = "0";
                                item[Constants.emailSent] = "0";
                                item[Constants.ApprovalRejectionEmailSent] = "0";
                                if (isPreApproved)
                                    item[Constants.userStatus] = Constants.JoineeApprovedStatus;
                                else
                                    item[Constants.userStatus] = Constants.Pending;
                                web.AllowUnsafeUpdates = true;
                                item.Update();
                                web.AllowUnsafeUpdates = false;


                                if (!isPreApproved)
                                {
                                    string approvalPage = string.Concat(subSiteURL, WebConfigurationManager.AppSettings["JoineeApprovalPage"], "?ID=" + item.ID + "&Status=" + Constants.JoineeApprovedStatus);
                                    string declinePage = string.Concat(subSiteURL, WebConfigurationManager.AppSettings["JoineeApprovalPage"], "?ID=" + item.ID + "&Status=" + Constants.Declined);
                                    string subject = string.Empty, body = string.Empty;

                                    //Getting Email Subject and Body
                                    Utility.GetEmailSubjectAndBody(web, Constants.JoineeCreationApproval, out subject, out body);
                                    if (!string.IsNullOrEmpty(subject) && !string.IsNullOrEmpty(body))
                                    {
                                        body = string.Format(body, firstName, lastName, email, approvalPage, declinePage);
                                        string fromEmail = WebConfigurationManager.AppSettings["FromEmail"];
                                        bool isEmailSent = Utility.SendEmail(Convert.ToString(coll[0][Constants.email]), fromEmail, subject, body);
                                        if (isEmailSent)
                                        {
                                            item[Constants.emailSent] = "1";
                                            web.AllowUnsafeUpdates = true;
                                            item.Update();
                                            web.AllowUnsafeUpdates = false;
                                        }
                                    }
                                }
                                ShowNextStep(divSuccess);
                            }
                            else
                            {
                                ShowNextStep(divFailure);
                            }

                        }
                    }

                });
            }
            catch (Exception ex)
            {
                lblMessage.Text = "<br/><br/>" + ex.Message;
                Utility.LogError("WaterXchange - Join Organization", ex);
            }
        }
    }
}
