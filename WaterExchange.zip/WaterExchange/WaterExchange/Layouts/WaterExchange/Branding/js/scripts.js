/*	===================================================================
	Minified Nav Bar
	===================================================================	*/
$(document).scroll(function (){
	var value = $(this).scrollTop();
	/* Show "Back to Top" button */
	if ( value > 100 ){
		$(".back-to-top").addClass('show-to-top');
	} else {
		$(".back-to-top").removeClass('show-to-top');
	}
});
/*	===================================================================
	Toggles
	===================================================================	*/
jQuery(document).ready(function(){

	/* Add Blur on Click*/
	$('.navbar-toggle').click(function(){
		$(".create-account").addClass('blur');
	});
	$('.close').click(function(){
		$(".create-account").removeClass('blur');
	});
	/* Video Cover Image */
	$('.frame').mouseover(function(){
    	$('.cover').addClass('fadeMeOut');
    	setTimeout(function(){
	    	$('.cover').removeClass('cover');
    	},500)
	});
	/* Function to prevent Default Events */
	function pde(e){
		if (e.preventDefault)
			e.preventDefault();
		else
			e.returnValue = false;
	}
	/* Scroll on Top */
	$('.back-to-top,.top').click(function(evt){
		$('html, body').animate({scrollTop: '0'}, 1200, 'easeInOutCubic');
		pde(evt);
	});
	/* Scroll with class */
	jQuery('.scroll').bind('click',function(event){
		var anchor = jQuery(this);
		jQuery('html, body').stop().animate({
			scrollTop: jQuery(anchor.attr('href')).offset().top-50},1500,'easeInOutExpo');
		event.preventDefault();
	});
});
/*	===================================================================
	Parallax
	===================================================================	*/
(function($){
	$.fn.parallax = function(options){
		var windowHeight = $(window).height();
		// Establish default settings
		var settings = $.extend({speed: 0.20}, options);
		return this.each( function(){
			var $this = $(this);
			$(document).scroll(function(){
			var scrollTop = $(window).scrollTop();
			var offset = $this.offset().top;
			var height = $this.outerHeight();
		if (offset + height <= scrollTop || offset >= scrollTop + windowHeight){
		return;
		}
		var yBgPosition = Math.round((offset - scrollTop) * settings.speed);
		// Apply the Y Background Position to Set the Parallax Effect
		$this.css('background-position', 'center ' + yBgPosition + 'px');
			});
		});
	}
}(jQuery));
	/* iOS */
	var userAgent = window.navigator.userAgent;
	if (userAgent.match(/iPad/i) || userAgent.match(/iPhone/i)){
		$('.parallax').removeClass('parallax').addClass('parallax-mobile');
	}
	$('.parallax').parallax({
	speed: 0.20
});
/*	===================================================================
	Covering IE
	===================================================================	*/
document.createElement("section");