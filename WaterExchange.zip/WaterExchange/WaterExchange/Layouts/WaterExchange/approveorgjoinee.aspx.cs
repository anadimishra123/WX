﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.Security;
using System.Web.Configuration;

namespace WaterExchange.Layouts.WaterExchange
{
    public partial class ApproveOrgJoinee : LayoutsPageBase
    {

        string joineeID = string.Empty;
        string status = string.Empty;

        private void ShowDiv(string message)
        {
            divSuccess.Style.Add("display", "block");
            lblMessage.Text = message;
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    joineeID = Request.QueryString["ID"];
                    status = Request.QueryString["Status"];
                    if (!string.IsNullOrEmpty(joineeID) && !string.IsNullOrEmpty(status))
                    {
                        string siteURL = SPContext.Current.Site.Url;
                        string approverEmail = SPContext.Current.Web.CurrentUser.Email;
                        string approverLoginName = SPContext.Current.Web.CurrentUser.LoginName.ToLower();


                        SPSecurity.RunWithElevatedPrivileges(delegate
                        {
                            using (SPSite site = new SPSite(siteURL))
                            {
                                SPWeb web = site.RootWeb;
                                SPList listJoinee = web.Lists.TryGetList(Constants.joineesList);

                                if (listJoinee != null)
                                {
                                    SPListItem item = listJoinee.GetItemById(int.Parse(joineeID));
                                    if (item != null)
                                    {
                                        if (Convert.ToString(item[Constants.userStatus]).Equals(Constants.Pending))
                                        {
                                            //var Organization = (SPFieldLookupValue)item[Constants.userOrg];
                                            var Organization = new SPFieldLookupValue(item[Constants.userOrg] as string ?? string.Empty);

                                            SPList listOrganization = web.Lists.TryGetList(Constants.organizationList);
                                            SPListItem itemOrg = listOrganization.GetItemById(Organization.LookupId);
                                            string approvalGroup = Convert.ToString(itemOrg[Constants.email]).ToLower();

                                            if (approvalGroup.Equals(approverEmail,StringComparison.CurrentCultureIgnoreCase) || approverLoginName.Contains(approvalGroup))
                                            {
                                                Utility utility = new Utility();
                                                string message = utility.ApproveJoinee(joineeID, status);
                                                ShowDiv(message);
                                            }
                                            else
                                            {
                                                ShowDiv("You are not the authorized approver");
                                            }
                                        }
                                        else
                                        {
                                            ShowDiv("Joinee selected for Approval/Rejection is no more valid or Joinee does not exist.");
                                        }
                                    }
                                }
                                else
                                {
                                    ShowDiv("Joinee does not exist");
                                }
                            }
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                ShowDiv(ex.Message);
                Utility.LogError("WaterXchange - Approve Joinee", ex);
            }
        }

       
    }
}
