﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.IdentityModel.Pages;
using Microsoft.SharePoint.Utilities;
using System.Web.UI.WebControls;

namespace WaterExchange.Layouts.WaterExchange
{
    public partial class HomeLogin : FormsSignInPage
    {

        protected override void OnInit(EventArgs eventArgs)
        {
            base.OnInit(eventArgs);
        }
        protected override void OnLoad(EventArgs e)
        {
            try
            {
                
                base.OnLoad(e);
                
            }
            catch { }
        }

      
        protected void Register_OnClick(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            Response.Redirect("registerorg.aspx");            
        }


        protected void SignUp_OnClick(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            Response.Redirect("joinorg.aspx");
        }
        
    }
}
