﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Security;

namespace WaterExchange
{
    public class Utility
    {

        public static void LogError(string Title, Exception ex)
        {
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory(Title, TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
        }

        /// <summary>
        /// This function will get Subject and Body of email from Mail Config List based on Title provided
        /// </summary>
        /// <param name="web"></param>
        /// <param name="Title"></param>
        /// <param name="Subject"></param>
        /// <param name="Body"></param>
        public static void GetEmailSubjectAndBody(SPWeb web, string Title, out string Subject, out string Body)
        {
            Subject = string.Empty;
            Body = string.Empty;
            try
            {

                string camlQuery = @"<Where>
                                            <Eq>
                                                <FieldRef Name='Title' />
                                                <Value Type='Text'>{0}</Value>
                                            </Eq>                                           
                                        </Where>";
                SPQuery query = new SPQuery();
                query.Query = string.Format(camlQuery, Title);
                query.ViewFields = "<FieldRef Name ='Subject'/><FieldRef Name ='Body'/>";
                SPList listMailConfig = web.Lists.TryGetList(Constants.MailConfigList);
                SPListItemCollection itemConfig = listMailConfig.GetItems(query);

                if (itemConfig != null && itemConfig.Count > 0)
                {
                    SPListItem item = itemConfig[0];
                    Subject = Convert.ToString(item["Subject"]);
                    Body = Convert.ToString(item["Body"]);
                }

            }
            catch (Exception ex)
            {
                Utility.LogError("WaterXchange - Getting Email Subject and Body", ex);
            }
        }

        public static bool SendEmail(string Emails, string From, SPWeb web, string Title, string URL)
        {
            string returnMessage = string.Empty;
            bool bSuccessful = false;
            try
            {

                string camlQuery = @"<Where>
                                            <Eq>
                                                <FieldRef Name='Title' />
                                                <Value Type='Text'>{0}</Value>
                                            </Eq>                                           
                                        </Where>";
                SPQuery query = new SPQuery();
                query.Query = string.Format(camlQuery, Title);
                query.ViewFields = "<FieldRef Name ='Subject'/><FieldRef Name ='Body'/>";

                SPList listMailConfig = web.Lists.TryGetList(Constants.MailConfigList);
                SPListItemCollection itemConfig = listMailConfig.GetItems(query);
                string MailSubject = string.Empty; string MailBody = string.Empty;
                if (itemConfig != null && itemConfig.Count > 0)
                {
                    MailSubject = Convert.ToString(itemConfig[0]["Subject"]);
                    if (!string.IsNullOrEmpty(URL))
                        MailBody = string.Format(Convert.ToString(itemConfig[0]["Body"]), URL);
                    else
                        MailBody = Convert.ToString(itemConfig[0]["Body"]);

                    if (!string.IsNullOrEmpty(MailBody) && !string.IsNullOrEmpty(MailSubject))
                    {
                        var messageHeaders = new StringDictionary();
                        messageHeaders.Add("to", Emails);
                        messageHeaders.Add("from", From);
                        messageHeaders.Add("subject", MailSubject);

                        string mimeType = "text/html";
                        messageHeaders.Add("content-type", mimeType);

                        bSuccessful = SPUtility.SendEmail(
                              web,
                              messageHeaders,
                              MailBody);


                    }
                    else
                    {
                        returnMessage = "Approval Mail Body/Subject not configured. Please contact administrator";

                    }
                }

            }
            catch (SmtpException ex)
            {
                returnMessage = "SMTP Error occured during Approval Process. Please contact administrator. Exception Details:" + ex.Message;


            }
            catch (Exception ex)
            {
                returnMessage = "Error occured during Approval Process Send Mail. Please contact administrator. Exception Details:" + ex.Message;

            }
            if (!bSuccessful)
            {
                returnMessage = "Approval Mail not sent. Please contact administrator";
            }

            return bSuccessful;
        }


        /// <summary>
        /// Send Email by passing parameters
        /// </summary>
        /// <param name="web"></param>
        /// <param name="Emails"></param>
        /// <param name="From"></param>
        /// <param name="MailSubject"></param>
        /// <param name="MailBody"></param>
        /// <returns></returns>
        public static bool SendEmail(string Emails, string From, string MailSubject, string MailBody)
        {
            bool bSuccessful = false;
            try
            {
                if (!string.IsNullOrEmpty(MailBody) && !string.IsNullOrEmpty(MailSubject))
                {
                    string siteURL = SPContext.Current.Site.Url;
                    SPSecurity.RunWithElevatedPrivileges(delegate
                    {
                        using (SPSite site = new SPSite(siteURL))
                        {
                            using (SPWeb web = site.OpenWeb())
                            {
                                var messageHeaders = new StringDictionary();
                                messageHeaders.Add("to", Emails);
                                //messageHeaders.Add("from", From);
                                messageHeaders.Add("subject", MailSubject);

                                string mimeType = "text/html";
                                messageHeaders.Add("content-type", mimeType);

                                bSuccessful = SPUtility.SendEmail(
                                      web,
                                      messageHeaders,
                                      MailBody);
                            }

                        }
                    });

                }
            }
            catch (SmtpException ex)
            {
                bSuccessful = false;
                Utility.LogError("WaterXchange - Send Email", ex);
            }
            catch (Exception ex)
            {
                bSuccessful = false;
                Utility.LogError("WaterXchange - Send Email", ex);
            }
            return bSuccessful;
        }


        /// <summary>
        /// This function is called by Timer Job and is used to send emails
        /// </summary>
        /// <param name="Emails"></param>
        /// <param name="From"></param>
        /// <param name="MailSubject"></param>
        /// <param name="MailBody"></param>
        /// <param name="siteURL"></param>
        /// <returns></returns>
        public static bool SendEmail(string Emails, string From, string MailSubject, string MailBody, string siteURL)
        {
            bool bSuccessful = false;
            try
            {
                if (!string.IsNullOrEmpty(MailBody) && !string.IsNullOrEmpty(MailSubject))
                {                    
                    SPSecurity.RunWithElevatedPrivileges(delegate
                    {
                        using (SPSite site = new SPSite(siteURL))
                        {
                            using (SPWeb web = site.OpenWeb())
                            {
                                var messageHeaders = new StringDictionary();
                                messageHeaders.Add("to", Emails);
                                //messageHeaders.Add("from", From);
                                messageHeaders.Add("subject", MailSubject);

                                string mimeType = "text/html";
                                messageHeaders.Add("content-type", mimeType);

                                bSuccessful = SPUtility.SendEmail(
                                      web,
                                      messageHeaders,
                                      MailBody);
                            }

                        }
                    });

                }
            }
            catch (SmtpException ex)
            {
                bSuccessful = false;
            }
            catch (Exception ex)
            {
                bSuccessful = false;
            }
            return bSuccessful;
        }


        /// <summary>
        /// This function will only update the Approval status of Organization, but not create organization site
        /// </summary>
        /// <param name="orgID"></param>
        /// <param name="Status"></param>
        /// <returns></returns>
        public string ApproveOrganization(string orgID, string Status)
        {
            string message = string.Empty;
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    string siteURL = SPContext.Current.Site.Url;
                    using (SPSite site = new SPSite(siteURL))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList listOrganization = web.Lists.TryGetList(Constants.organizationList);

                            if (listOrganization != null)
                            {
                                SPListItem item = listOrganization.GetItemById(int.Parse(orgID));
                                web.AllowUnsafeUpdates = true;
                                if (Status == Constants.Declined)
                                    item[Constants.orgStatus] = Constants.Rejected;

                                if (Status == Constants.JoineeApprovedStatus)
                                {
                                    item[Constants.orgStatus] = Constants.Approved;
                                    bool isUserCreated = false;
                                    FBAUser user = new FBAUser();
                                    user.Name = Convert.ToString(item[Constants.firstName]) + " " + Convert.ToString(item[Constants.lastName]);
                                    user.Email = Convert.ToString(item[Constants.email]);
                                    user.Password = Utility.Decrypt(Convert.ToString(item[Constants.password]));
                                    MembershipUser userMembership = null;
                                    try
                                    {                                        
                                        userMembership = Membership.CreateUser(user.Email, user.Password, user.Email);
                                        if (userMembership != null)
                                            isUserCreated = true;
                                        if (isUserCreated)
                                        {
                                            item[Constants.userCreated] = "1";
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        isUserCreated = false;
                                        LogError("WaterXchange - FBA User Creation - Organization", ex);
                                    }
                                }

                                item.Update();

                                web.AllowUnsafeUpdates = false;

                                message = "Organization " + Status + " successfully";

                            }
                            else
                            {
                                message = "Organization does not exists";
                            }
                        }

                    }
                });
            }
            catch (Exception ex)
            {
                message = ex.Message;
                LogError("WaterXchange - Approval Organization", ex);
            }


            return message;
        }


        /// <summary>
        /// This function will Approve Organization, send email to Org Admin and setup the Org site for Org Admin
        /// </summary>
        /// <param name="orgID"></param>
        /// <returns></returns>
        public string ApproveOrganization(string orgID)
        {
            bool isSiteCreated = false, isEmailSent = false;
            string URL = string.Empty, message = string.Empty;
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    string siteURL = SPContext.Current.Site.Url;
                    using (SPSite site = new SPSite(siteURL))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList listOrganization = web.Lists.TryGetList(Constants.organizationList);

                            if (listOrganization != null)
                            {
                                SPListItem item = listOrganization.GetItemById(int.Parse(orgID));
                                web.AllowUnsafeUpdates = true;

                                FBAUser user = new FBAUser();
                                user.Name = Convert.ToString(item["FirstName"]) + " " + Convert.ToString(item["LastName"]);
                                user.Email = Convert.ToString(item["Email"]);
                                user.Password = Utility.Decrypt(Convert.ToString(item["Password"]));
                                user.OrganizationName = Convert.ToString(item["OrganizationName"]);
                                string emailStatus = string.Empty;


                                #region Create-Site
                                isSiteCreated = false;
                                try
                                {
                                    SPWeb webOrg = web.Webs.Add(user.OrganizationName.Replace(" ", ""), user.OrganizationName, string.Empty, Convert.ToUInt32(1033), SPWebTemplate.WebTemplateSTS, true, false);
                                    URL = webOrg.Url;
                                    isSiteCreated = true;

                                    MembershipUser userMembership = Membership.CreateUser(user.Email, user.Password, user.Email);
                                    string membserhip = WebConfigurationManager.AppSettings["MembershipName"];

                                    if (userMembership != null)
                                    {
                                        string userName = string.Concat("i:0#.f|", membserhip, "|", user.Email);
                                        SPRoleAssignment roleAssignment = new SPRoleAssignment(userName, user.Email, user.Name, string.Empty);
                                        SPRoleDefinition roleDefinition = webOrg.RoleDefinitions.GetByType(SPRoleType.Administrator);
                                        roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                        webOrg.AllowUnsafeUpdates = true;
                                        webOrg.RoleAssignments.Add(roleAssignment);
                                        webOrg.Update();
                                        webOrg.AllowUnsafeUpdates = false;
                                    }
                                }
                                catch (Exception ex)
                                {
                                    isSiteCreated = false;
                                }
                                #endregion

                                #region Send Approval Email 

                                isEmailSent = false;
                                isEmailSent = Utility.SendEmail(user.Email, "admin@WaterXchange.org", web, "Organization Approval", URL);

                                #endregion

                                if (isSiteCreated && isEmailSent)
                                {
                                    item["Status"] = Constants.Approved;
                                    item["SiteCreated"] = "1";
                                    item["EmailSent"] = "1";
                                    item["OrgURL"] = URL;
                                }
                                else if (isSiteCreated && !isEmailSent)
                                {
                                    item["Status"] = Constants.ApprovedButNotSetup;
                                    item["SiteCreated"] = "1";
                                    item["EmailSent"] = "0";
                                    item["OrgURL"] = URL;
                                }
                                else if (!isSiteCreated && isEmailSent)
                                {
                                    item["Status"] = Constants.ApprovedButNotSetup;
                                    item["SiteCreated"] = "0";
                                    item["EmailSent"] = "1";
                                }
                                else
                                {
                                    item["Status"] = Constants.ApprovedButNotSetup;
                                    item["SiteCreated"] = "0";
                                    item["EmailSent"] = "0";
                                }
                                item.Update();

                                web.AllowUnsafeUpdates = false;
                                if (!isSiteCreated)
                                    emailStatus += ". There is an error in creating organization site";
                                if (!isEmailSent)
                                    emailStatus += ". There is an error in sending email to Org Admin";
                                message = "Organization approved successfully" + emailStatus;

                            }
                            else
                            {
                                message = "Organization does not exists";
                            }
                        }

                    }
                });
            }
            catch (Exception ex)
            {
                message = ex.Message;
            }


            return message;
        }

        /// <summary>
        /// This function will Reject the Organization Approval request, send email to Org Admin to inform the rejection
        /// </summary>
        /// <param name="orgID"></param>
        /// <returns></returns>
        public string RejectOrganization(string orgID)
        {
            string message = string.Empty;
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    string siteURL = SPContext.Current.Site.Url;
                    using (SPSite site = new SPSite(siteURL))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList listOrganization = web.Lists.TryGetList(Constants.organizationList);

                            if (listOrganization != null)
                            {
                                SPListItem item = listOrganization.GetItemById(int.Parse(orgID));
                                string Email = Convert.ToString(item["Email"]);
                                item["Status"] = Constants.Rejected;
                                web.AllowUnsafeUpdates = true;
                                item.Update();
                                bool isEmailSent = Utility.SendEmail(Email, "admin@WaterXchange.org", web, Constants.OrganizationRejection, string.Empty);
                                web.AllowUnsafeUpdates = false;
                                string emailStatus = string.Empty;
                                if (!isEmailSent)
                                    emailStatus = " but there is an arror while sending email to Org Admin";
                                message = "Organization Rejected successfully" + emailStatus;

                            }
                            else
                            {
                                message = "Organization does not exists";
                            }
                        }

                    }
                });
            }
            catch (Exception ex)
            {
                message = ex.Message;
            }
            return message;
        }



        /// <summary>
        /// This function will make the Organization Inactive
        /// </summary>
        /// <param name="orgID"></param>
        /// <returns></returns>
        public string InactiveOrganization(string orgID)
        {
            string message = string.Empty;
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    string siteURL = SPContext.Current.Site.Url;
                    using (SPSite site = new SPSite(siteURL))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList listOrganization = web.Lists.TryGetList(Constants.organizationList);

                            if (listOrganization != null)
                            {
                                SPListItem item = listOrganization.GetItemById(int.Parse(orgID));
                                FBAUser user = new FBAUser();
                                user.Name = Convert.ToString(item["FirstName"]) + " " + Convert.ToString(item["LastName"]);
                                user.Email = Convert.ToString(item["Email"]);
                                user.Password = Convert.ToString(item["Password"]);
                                user.OrganizationName = Convert.ToString(item["OrganizationName"]);
                                user.SiteURL = Convert.ToString(item["OrgURL"]);
                                string membserhip = WebConfigurationManager.AppSettings["MembershipName"];
                                string userName = string.Concat("i:0#.f|", membserhip, "|", user.Email);
                                bool isRoleUpdated = false;
                                try
                                {
                                    using (SPSite siteOrg = new SPSite(user.SiteURL))
                                    {
                                        SPWeb webOrg = siteOrg.OpenWeb();
                                        webOrg.AllowUnsafeUpdates = true;
                                        webOrg.Users.Remove(userName);
                                        webOrg.Update();
                                        webOrg.AllowUnsafeUpdates = false;

                                        isRoleUpdated = true;
                                    }

                                }
                                catch (Exception ex)
                                {
                                    isRoleUpdated = false;
                                }

                                if (isRoleUpdated)
                                {
                                    item["Status"] = Constants.Inactive;
                                    web.AllowUnsafeUpdates = true;
                                    item.Update();
                                    web.AllowUnsafeUpdates = false;
                                    message = "Organization Deactivated successfully";
                                }
                                else
                                {
                                    message = "Error occured deactivating the Organization";
                                }
                            }
                            else
                            {
                                message = "Organization does not exists";
                            }
                        }

                    }
                });
            }
            catch (Exception ex)
            {
                message = ex.Message;
            }
            return message;
        }


        /// <summary>
        /// This function will only update the Approval status of Org Joinee, but not create joinee FBA user and neither add user to org site
        /// </summary>
        /// <param name="JoineeID"></param>
        /// <param name=""></param>
        /// <param name="Status"></param>
        /// <returns></returns>
        public string ApproveJoinee(string JoineeID, string Status)
        {
            string URL = string.Empty, message = string.Empty;
            try
            {
                string siteURL = SPContext.Current.Site.Url;
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    using (SPSite site = new SPSite(siteURL))
                    {
                        SPWeb web = site.RootWeb;
                        SPList listJoinee = web.Lists.TryGetList(Constants.joineesList);

                        if (listJoinee != null)
                        {
                            SPListItem item = listJoinee.GetItemById(int.Parse(JoineeID));
                            //var Organization = (SPFieldLookupValue)item[Constants.userOrg];
                            var Organization = new SPFieldLookupValue(item[Constants.userOrg] as string ?? string.Empty);

                            SPList listOrganization = web.Lists.TryGetList(Constants.organizationList);
                            SPListItem itemOrg = listOrganization.GetItemById(Organization.LookupId);

                            web.AllowUnsafeUpdates = true;

                            if (Status == Constants.userStatus)
                                item[Constants.status] = Constants.JoineeDeniedStatus;
                            if (Status == Constants.JoineeApprovedStatus)
                            {
                                item[Constants.userStatus] = Constants.JoineeApprovedStatus;
                                bool isUserCreated = false;
                                FBAUser user = new FBAUser();
                                user.Name = Convert.ToString(item[Constants.firstName]) + " " + Convert.ToString(item[Constants.lastName]);
                                user.Email = Convert.ToString(item[Constants.email]);
                                user.Password = Utility.Decrypt(Convert.ToString(item[Constants.password]));
                                user.SiteURL = Convert.ToString(itemOrg[Constants.orgURL]);

                                MembershipUser userMembership = null;
                                if (!isUserCreated)
                                {
                                    try
                                    {
                                        userMembership = Membership.CreateUser(user.Email, user.Password, user.Email);
                                        if (userMembership != null)
                                            isUserCreated = true;
                                        if (isUserCreated)
                                        {
                                            item[Constants.userCreated] = "1";
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        isUserCreated = false;
                                        Utility.LogError("WaterXchange - FBA User Creation: Joinee", ex);
                                    }
                                }
                            }

                            item.Update();
                            web.AllowUnsafeUpdates = false;
                            message = "Joinee " + Status + " successfully";

                        }
                        else
                        {
                            message = "Joinee does not exists";
                        }

                    }
                });
            }
            catch (Exception ex)
            {
                message = ex.Message;
                Utility.LogError("WaterXchange - Approve Joinee", ex);
            }
            return message;
        }

        
        /// <summary>
        /// This Function is used to get the Approval group
        /// </summary>
        /// <param name="web"></param>
        /// <returns></returns>
        public string GetApprovalGroup(SPWeb web)
        {

            string camlQuery = @"<Where><Eq>
                                                <FieldRef Name='Key' />
                                                <Value Type='Text'>{0}</Value>
                                            </Eq>                                           
                                        </Where>";
            SPQuery query = new SPQuery();
            query.Query = string.Format(camlQuery, "Approver Group");
            query.ViewFields = "<FieldRef Name ='Value'/>";


            SPList listConfigMaster = web.Lists.TryGetList(Constants.ConfigMasterList);
            SPListItemCollection itemConfig = listConfigMaster.GetItems(query);
            string approverGroup = string.Empty;
            if (itemConfig != null && itemConfig.Count > 0)
            {
                approverGroup = Convert.ToString(itemConfig[0]["Value"]);
            }
            return approverGroup;
        }


        /// <summary>
        /// This function is used to Encrypt password and then store in SharePoint list
        /// </summary>
        /// <param name="clearText"></param>
        /// <returns></returns>
        public static string Encrypt(string clearText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    clearText = Convert.ToBase64String(ms.ToArray());
                }
            }
            return clearText;
        }



        /// <summary>
        /// This function will Decrypt password before storing into Sql membership database
        /// </summary>
        /// <param name="cipherText"></param>
        /// <returns></returns>
        public static string Decrypt(string cipherText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }


        /// <summary>
        /// This function will give the email ids of preapproved joinees for any specific organization
        /// </summary>
        /// <param name="OrgID"></param>
        /// <returns></returns>
        public static string GetPreApprovedJoinees(string OrgID)
        {
            string JoineeEmails = string.Empty;
            try
            {
                string siteURL = SPContext.Current.Site.Url;
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    using (SPSite site = new SPSite(siteURL))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList listPreApprovedJoinees = web.Lists.TryGetList(Constants.PreApprovedJoineesList);

                            if (listPreApprovedJoinees != null)
                            {
                                string camlQuery = @"<Where>
                                                        <Eq>
                                                            <FieldRef Name='Organization' LookupId ='TRUE' />
                                                            <Value Type='Lookup'>" + OrgID + @"</Value>
                                                        </Eq>                                           
                                                    </Where>";

                                SPListItemCollection coll = listPreApprovedJoinees.GetItems(camlQuery);
                                if (coll != null && coll.Count > 0)
                                {
                                    SPListItem item = coll[0];
                                    JoineeEmails = Convert.ToString(item[Constants.joineeEmails]);
                                }

                            }
                        }

                    }
                });
            }
            catch (Exception ex)
            {
            }
            return JoineeEmails;

        }

    }
}
